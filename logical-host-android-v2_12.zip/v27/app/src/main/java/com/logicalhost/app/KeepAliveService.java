package com.logicalhost.app;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import androidx.core.app.NotificationCompat;

/**
 * Keeps the app alive in the background. The floating bubble is the WEB page's
 * own bubble (skinned with the app logo by bridge.js), so this service no longer
 * draws any overlay.
 */
public class KeepAliveService extends Service {

    static final String ACTION_STOP = "com.logicalhost.app.STOP";
    private static final String CHANNEL = "running";
    private static final int NOTIF_ID = 1;

    static KeepAliveService instance;

    // Set by the web page (bridge.js -> NotifyBridge.botState). Main thread only.
    static boolean botOn = false;

    private PowerManager.WakeLock lock;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        botOn = false; // never trust old state after a (re)start

        NotificationChannel ch = new NotificationChannel(
                CHANNEL, "Bot running", NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        lock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "logicalhost:bot");
        lock.setReferenceCounted(false);
        lock.acquire();

        WebHost.get(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            botOn = false;
            stopForeground(STOP_FOREGROUND_REMOVE);
            Activity a = WebHost.activity;
            if (a != null) a.finish();
            WebHost.destroy();
            stopSelf();
            return START_NOT_STICKY;
        }

        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIF_ID, n);
        }
        return START_STICKY;
    }

    private Notification buildNotification() {
        // Tapping the notification opens the app on the web bot console.
        Intent open = new Intent(this, MainActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra(MainActivity.EXTRA_OPEN_CONSOLE, true);
        PendingIntent openPi = PendingIntent.getActivity(
                this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Intent stop = new Intent(this, KeepAliveService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(
                this, 1, stop, PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle("Logical Host is online")
                .setContentText("Bot is running. Tap to open.")
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(openPi)
                .addAction(0, "Stop", stopPi)
                .build();
    }

    @Override
    public void onDestroy() {
        botOn = false;
        if (lock != null && lock.isHeld()) lock.release();
        if (!MainActivity.visible) WebHost.destroy();
        instance = null;
        super.onDestroy();
    }
}
