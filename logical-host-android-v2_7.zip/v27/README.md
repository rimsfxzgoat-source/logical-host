# Logical Host - Android app v2.7

Native floating bubble removed. The bubble is now the web page's own bubble,
skinned with the app logo (bridge.js).

- The bubble shows ONLY while the bot is running (the web page decides this).
- Tap the bubble: the web bot console opens (same as before).
- Tap the "Bot is running" notification or a signal alert: the app opens
  straight onto the web bot console.
- No "display over other apps" permission is requested anymore.

Files that matter:
- app/src/main/java/com/logicalhost/app/KeepAliveService.java  foreground service, Stop action
- app/src/main/java/com/logicalhost/app/WebHost.java           one shared WebView, openConsole()
- app/src/main/java/com/logicalhost/app/MainActivity.java      the screen, opens console on tap
- app/src/main/java/com/logicalhost/app/NotifyBridge.java      notifications + botState() from the page
- app/src/main/assets/bridge.js                                skins .float-bubble with the logo, signal alerts

Change the page the app opens: HOME_URL in WebHost.java.
Logo: the same vector as res/drawable/ic_fg.xml, duplicated as SVG in bridge.js (LOGO_SVG).
