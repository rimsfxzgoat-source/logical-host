(function () {
  if (window.__lhNative) return;
  window.__lhNative = true;

  function show(title, body) {
    try { window.AndroidNotify.show(String(title || ''), String(body || '')); } catch (e) {}
  }

  // 1) Notification polyfill. The chart scanner calls new Notification(...).
  function N(title, opts) {
    opts = opts || {};
    show(title, opts.body);
    this.close = function () {};
  }
  N.permission = 'granted';
  N.requestPermission = function (cb) {
    if (cb) cb('granted');
    return Promise.resolve('granted');
  };
  try {
    Object.defineProperty(window, 'Notification', { value: N, configurable: true, writable: true });
  } catch (e) {
    window.Notification = N;
  }

  // 2) Signal watcher. Reads the app's own EaSignal responses and notifies on NEW ones.
  var EV = { open: 1, close: 1, modify: 1, pending: 1 };
  var seen = {};
  var maxTs = 0;
  var ready = false;

  function up(x) { return String(x == null ? '' : x).toUpperCase(); }
  function pos(x) { var n = Number(x); return isFinite(n) && n > 0 ? n : null; }

  function ts(e) {
    var s = e.created_date;
    if (!s) return 0;
    s = String(s);
    if (!/[zZ]$|[+-]\d\d:?\d\d$/.test(s)) s += 'Z';
    var t = Date.parse(s);
    return isNaN(t) ? 0 : t;
  }

  function build(e) {
    var sym = up(e.symbol);
    var dir = e.direction && e.direction !== 'none' ? up(e.direction) : '';
    var parts = [];
    if (pos(e.lot)) parts.push(pos(e.lot) + ' lot');
    if (pos(e.price)) parts.push('@ ' + e.price);
    if (pos(e.sl)) parts.push('SL ' + e.sl);
    if (pos(e.tp)) parts.push('TP ' + e.tp);
    var extra = parts.join(' \u00b7 ');
    var t, b;
    if (e.event === 'open') {
      t = (dir ? dir + ' ' : '') + sym;
      b = 'Trade opened' + (extra ? ' \u00b7 ' + extra : '');
    } else if (e.event === 'pending') {
      t = 'PENDING ' + (dir ? dir + ' ' : '') + sym;
      b = 'Entry order' + (extra ? ' \u00b7 ' + extra : '');
    } else if (e.event === 'modify') {
      t = sym + ' UPDATED';
      b = 'SL/TP changed' + (extra ? ' \u00b7 ' + extra : '');
    } else {
      t = sym + ' CLOSED';
      b = typeof e.profit === 'number' ? 'P/L ' + e.profit : 'Trade closed';
      if (extra) b += ' \u00b7 ' + extra;
    }
    if (e.message && e.account === 'manual') b = String(e.message);
    return [t, b];
  }

  function handle(list, isEventQuery) {
    var items = [], i, e;
    for (i = 0; i < list.length; i++) {
      e = list[i];
      if (e && e.id && EV[e.event]) items.push(e);
    }
    items.sort(function (a, b) { return ts(a) - ts(b); });
    var now = Date.now();
    for (i = 0; i < items.length; i++) {
      e = items[i];
      if (seen[e.id]) continue;
      seen[e.id] = 1;
      var t = ts(e);
      var fresh = ready && t >= maxTs && (!t || now - t < 900000);
      if (t > maxTs) maxTs = t;
      if (fresh) {
        var m = build(e);
        show(m[0], m[1]);
      }
    }
    if (isEventQuery) ready = true;
  }

  function isEventUrl(url) {
    try { url = decodeURIComponent(url); } catch (e) {}
    return /open|close|modify|pending/.test(url) && !/heartbeat/.test(url);
  }

  function parse(data, url) {
    try {
      if (typeof data === 'string') data = JSON.parse(data);
      var list = Array.isArray(data) ? data :
        (data && (data.items || data.data || data.results || data.records || data.entities));
      handle(Array.isArray(list) ? list : [], isEventUrl(url));
    } catch (e) {}
  }


  // 3) Bot ON/OFF detection (drives the floating bubble).
  // While the bot is ON the app polls EaSignal events and updates StudentStatus.
  var botOn = false, lastSeen = 0;
  function setBot(on) {
    if (on === botOn) return;
    botOn = on;
    try { window.AndroidNotify.botState(on); } catch (e) {}
  }
  function trackBot(url, body) {
    try {
      url = String(url || '');
      if (url.indexOf('EaSignal') > -1 && isEventUrl(url)) {
        lastSeen = Date.now();
        setBot(true);
        return;
      }
      if (url.indexOf('StudentStatus') > -1 && typeof body === 'string') {
        var b = JSON.parse(body);
        if (b && typeof b.bot_on === 'boolean') {
          if (b.bot_on) { lastSeen = Date.now(); setBot(true); } else { setBot(false); }
        }
      }
    } catch (e) {}
  }
  setInterval(function () {
    if (botOn && Date.now() - lastSeen > 25000) setBot(false);
  }, 5000);

  // XMLHttpRequest (axios)
  try {
    var oOpen = XMLHttpRequest.prototype.open;
    var oSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function (m, u) {
      this.__lhUrl = String(u);
      return oOpen.apply(this, arguments);
    };
    XMLHttpRequest.prototype.send = function () {
      var x = this;
      trackBot(x.__lhUrl, arguments[0]);
      if (x.__lhUrl && x.__lhUrl.indexOf('EaSignal') > -1) {
        x.addEventListener('load', function () {
          try {
            var d = (x.responseType === '' || x.responseType === 'text') ? x.responseText : x.response;
            parse(d, x.__lhUrl);
          } catch (e) {}
        });
      }
      return oSend.apply(this, arguments);
    };
  } catch (e) {}

  // fetch
  try {
    var oFetch = window.fetch;
    if (oFetch) {
      window.fetch = function (input, init) {
        var url = typeof input === 'string' ? input : (input && input.url) || '';
        trackBot(url, init && init.body);
        var p = oFetch.apply(this, arguments);
        if (url.indexOf('EaSignal') > -1) {
          p.then(function (r) {
            try { r.clone().json().then(function (d) { parse(d, url); }).catch(function () {}); } catch (e) {}
          }).catch(function () {});
        }
        return p;
      };
    }
  } catch (e) {}
})();
