package com.logicalhost.app;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;

import androidx.core.app.NotificationCompat;

public class KeepAliveService extends Service {

    static final String ACTION_STOP = "com.logicalhost.app.STOP";
    private static final String CHANNEL = "running";
    private static final int NOTIF_ID = 1;

    static KeepAliveService instance;
    static boolean bubbleWanted = false; // set by the web page when the bot is ON

    private PowerManager.WakeLock lock;
    private WindowManager wm;
    private ImageView bubble;
    private WindowManager.LayoutParams lp;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;

        NotificationChannel ch = new NotificationChannel(
                CHANNEL, "Bot running", NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        lock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "logicalhost:bot");
        lock.setReferenceCounted(false);
        lock.acquire();

        WebHost.get(this);
        if (!MainActivity.visible) WebHost.park(this);
        showBubble();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            hideBubble();
            Activity a = WebHost.activity;
            if (a != null) a.finish();
            WebHost.destroy();
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            return START_NOT_STICKY;
        }

        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIF_ID, n);
        }
        return START_STICKY;
    }

    private Notification buildNotification() {
        PendingIntent open = PendingIntent.getActivity(
                this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, KeepAliveService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(
                this, 1, stop, PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle("Logical Host is online")
                .setContentText("Bot is running. Tap to open.")
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(open)
                .addAction(0, "Stop", stopPi)
                .build();
    }

    // ---------------- floating bubble ----------------

    void showBubble() {
        if (!bubbleWanted || bubble != null || MainActivity.visible
                || !Settings.canDrawOverlays(this)) return;

        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        final float d = getResources().getDisplayMetrics().density;
        final int size = (int) (56 * d);
        final int screenW = getResources().getDisplayMetrics().widthPixels;

        bubble = new ImageView(this);
        bubble.setBackgroundResource(R.drawable.bubble_bg);
        bubble.setImageResource(R.drawable.ic_fg);
        int pad = (int) (6 * d);
        bubble.setPadding(pad, pad, pad, pad);

        lp = new WindowManager.LayoutParams(
                size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = screenW - size;
        lp.y = (int) (200 * d);

        bubble.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY;
            float touchX, touchY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = lp.x;
                        startY = lp.y;
                        touchX = e.getRawX();
                        touchY = e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - touchX;
                        float dy = e.getRawY() - touchY;
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true;
                        lp.x = startX + (int) dx;
                        lp.y = startY + (int) dy;
                        wm.updateViewLayout(v, lp);
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) {
                            openConsole();
                        } else {
                            lp.x = (lp.x + size / 2 < screenW / 2) ? 0 : screenW - size;
                            wm.updateViewLayout(v, lp);
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });

        try {
            wm.addView(bubble, lp);
        } catch (Exception e) {
            bubble = null;
        }
    }

    void hideBubble() {
        if (bubble != null) {
            try {
                wm.removeView(bubble);
            } catch (Exception ignored) {
            }
            bubble = null;
        }
    }

    private void openConsole() {
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_SINGLE_TOP
                | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(i);
    }

    @Override
    public void onDestroy() {
        hideBubble();
        if (lock != null && lock.isHeld()) lock.release();
        if (!MainActivity.visible) WebHost.destroy();
        instance = null;
        super.onDestroy();
    }
}
