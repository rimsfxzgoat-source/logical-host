package com.logicalhost.app;

import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/**
 * Native bot console drawn on top of other apps. It does not use the WebView,
 * so it can never come up blank. Data comes from bridge.js (consoleState / consoleLine).
 * Everything here runs on the main thread.
 */
final class ConsoleOverlay {

    private static final int MAX_LINES = 40;
    private static final ArrayList<String[]> lines = new ArrayList<>(); // {kind, text, time}
    private static String state = "waiting";
    private static final SimpleDateFormat TIME = new SimpleDateFormat("HH:mm:ss", Locale.US);

    private static Context app;
    private static WindowManager wm;
    private static WindowManager.LayoutParams lp;
    private static LinearLayout root;
    private static LinearLayout list;
    private static ScrollView scroll;
    private static TextView pill;
    private static float d = 1f;
    private static int screenW = 0;
    private static int screenH = 0;

    private ConsoleOverlay() {}

    static boolean isShown() {
        return root != null;
    }

    private static int dp(float v) {
        return (int) (v * d);
    }

    // ---------------- data ----------------

    static void setState(String s) {
        state = s == null ? "waiting" : s;
        applyState();
    }

    static void addLine(String kind, String text, long ts) {
        String time = TIME.format(new Date(ts > 0 ? ts : System.currentTimeMillis()));
        lines.add(new String[]{kind == null ? "" : kind, text == null ? "" : text, time});
        while (lines.size() > MAX_LINES) lines.remove(0);
        rebuild();
    }

    // ---------------- show / hide ----------------

    static boolean show(Context c) {
        if (root != null) return true;
        try {
            app = c.getApplicationContext();
            wm = (WindowManager) app.getSystemService(Context.WINDOW_SERVICE);
            DisplayMetrics dm = app.getResources().getDisplayMetrics();
            d = dm.density;
            screenW = dm.widthPixels;
            screenH = dm.heightPixels;
            int w = (int) Math.min(screenW * 0.92f, 420 * d);
            int h = (int) Math.min(screenH * 0.62f, 540 * d);

            LinearLayout r = new LinearLayout(app);
            r.setOrientation(LinearLayout.VERTICAL);
            GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{0xFA0C1228, 0xFC050814});
            bg.setCornerRadius(dp(22));
            bg.setStroke(Math.max(1, dp(1)), 0x663D6BFF);
            r.setBackground(bg);
            r.setPadding(dp(14), dp(2), dp(8), dp(12));

            // header: drag by the title, close with the X
            LinearLayout head = new LinearLayout(app);
            head.setOrientation(LinearLayout.HORIZONTAL);
            head.setGravity(Gravity.CENTER_VERTICAL);

            TextView title = new TextView(app);
            title.setText("BOT CONSOLE");
            title.setTextColor(0xFF8FB6FF);
            title.setTextSize(12);
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setLetterSpacing(0.16f);
            title.setPadding(0, dp(12), 0, dp(12));
            head.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            TextView close = new TextView(app);
            close.setText("\u2715");
            close.setTextColor(0xFF8FA3C8);
            close.setTextSize(17);
            close.setPadding(dp(14), dp(8), dp(14), dp(8));
            close.setOnClickListener(v -> hide(true));
            head.addView(close, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            r.addView(head, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            // status pill
            pill = new TextView(app);
            pill.setTextSize(10.5f);
            pill.setTypeface(Typeface.DEFAULT_BOLD);
            pill.setLetterSpacing(0.12f);
            pill.setPadding(dp(12), dp(6), dp(12), dp(6));
            LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            pl.bottomMargin = dp(8);
            r.addView(pill, pl);

            // live feed
            scroll = new ScrollView(app);
            scroll.setFillViewport(true);
            list = new LinearLayout(app);
            list.setOrientation(LinearLayout.VERTICAL);
            list.setPadding(dp(10), dp(6), dp(10), dp(6));
            GradientDrawable feedBg = new GradientDrawable();
            feedBg.setColor(0xD9040712);
            feedBg.setCornerRadius(dp(14));
            feedBg.setStroke(Math.max(1, dp(1)), 0x383D6BFF);
            scroll.setBackground(feedBg);
            scroll.addView(list, new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
            sl.rightMargin = dp(6);
            r.addView(scroll, sl);

            // footer
            TextView open = new TextView(app);
            open.setText("OPEN APP");
            open.setGravity(Gravity.CENTER);
            open.setTextColor(0xFF8FA3C8);
            open.setTextSize(11);
            open.setTypeface(Typeface.DEFAULT_BOLD);
            open.setLetterSpacing(0.14f);
            open.setPadding(0, dp(12), 0, dp(4));
            open.setOnClickListener(v -> {
                hide(true);
                try {
                    Intent i = new Intent(app, MainActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                    app.startActivity(i);
                } catch (Exception ignored) {
                }
            });
            LinearLayout.LayoutParams ol = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            ol.rightMargin = dp(6);
            r.addView(open, ol);

            lp = new WindowManager.LayoutParams(
                    w, h,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.x = (screenW - w) / 2;
            lp.y = dp(90);

            title.setOnTouchListener(new View.OnTouchListener() {
                int sx, sy;
                float tx, ty;

                @Override
                public boolean onTouch(View v, MotionEvent e) {
                    switch (e.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            sx = lp.x;
                            sy = lp.y;
                            tx = e.getRawX();
                            ty = e.getRawY();
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            lp.x = Math.max(0, Math.min(screenW - lp.width, sx + (int) (e.getRawX() - tx)));
                            lp.y = Math.max(0, Math.min(screenH - lp.height, sy + (int) (e.getRawY() - ty)));
                            try {
                                wm.updateViewLayout(root, lp);
                            } catch (Exception ignored) {
                            }
                            return true;
                        default:
                            return true;
                    }
                }
            });

            root = r;
            wm.addView(root, lp);
            applyState();
            rebuild();
            return true;
        } catch (Exception e) {
            root = null;
            list = null;
            scroll = null;
            pill = null;
            return false;
        }
    }

    /** Close the console. restoreBubble = show the floating bubble again. */
    static void hide(boolean restoreBubble) {
        if (root != null) {
            try {
                wm.removeView(root);
            } catch (Exception ignored) {
            }
        }
        root = null;
        list = null;
        scroll = null;
        pill = null;
        if (restoreBubble && KeepAliveService.instance != null) {
            KeepAliveService.instance.showBubble();
        }
    }

    // ---------------- drawing ----------------

    private static void applyState() {
        if (pill == null) return;
        String label;
        int color;
        if ("executing".equals(state)) {
            label = "EXECUTING";
            color = 0xFFFFB454;
        } else if ("monitoring".equals(state)) {
            label = "MONITORING";
            color = 0xFF34D399;
        } else {
            label = "WAITING FOR MENTOR SIGNAL";
            color = 0xFF8FB6FF;
        }
        pill.setText("\u25CF  " + label);
        pill.setTextColor(color);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(10));
        g.setColor((color & 0x00FFFFFF) | 0x24000000);
        g.setStroke(Math.max(1, dp(1)), (color & 0x00FFFFFF) | 0x66000000);
        pill.setBackground(g);
    }

    private static int kindColor(String kind) {
        switch (kind) {
            case "open": return 0xFF34D399;
            case "pending": return 0xFF4DA3FF;
            case "modify": return 0xFFFFB454;
            default: return 0xFF8FA3C8;
        }
    }

    private static void rebuild() {
        if (list == null || scroll == null) return;
        list.removeAllViews();
        if (lines.isEmpty()) {
            TextView e = new TextView(app);
            e.setText("Listening for signals\u2026");
            e.setTextColor(0xFF44567A);
            e.setTextSize(11);
            e.setGravity(Gravity.CENTER);
            e.setPadding(0, dp(40), 0, dp(40));
            list.addView(e);
            return;
        }
        for (String[] l : lines) list.addView(row(l));
        final ScrollView sv = scroll;
        sv.post(() -> sv.fullScroll(View.FOCUS_DOWN));
    }

    private static View row(String[] l) {
        LinearLayout r = new LinearLayout(app);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setPadding(0, dp(6), 0, dp(6));

        View dot = new View(app);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(kindColor(l[0]));
        dot.setBackground(g);
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(dp(8), dp(8));
        dl.topMargin = dp(5);
        dl.rightMargin = dp(10);
        r.addView(dot, dl);

        LinearLayout col = new LinearLayout(app);
        col.setOrientation(LinearLayout.VERTICAL);

        TextView t = new TextView(app);
        t.setText(l[1]);
        t.setTextColor(0xFFC9D6EF);
        t.setTextSize(12);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        col.addView(t);

        TextView ts = new TextView(app);
        ts.setText(l[2]);
        ts.setTextColor(0xFF44567A);
        ts.setTextSize(9);
        ts.setTypeface(Typeface.MONOSPACE);
        col.addView(ts);

        r.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return r;
    }
}
