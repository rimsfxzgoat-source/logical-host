# Logical Host - Android app v2.6

One floating bubble, same as the web app's own bubble:
- Shown ONLY while the bot is running (the web page's own bubble is the source of truth).
- Shown ONLY when you are outside the app (inside the app the web bubble is used).
- Tap it: the app opens with the web bot console already open.
- Bot off / Stop pressed / page reloaded: the bubble is gone.

Files that matter:
- app/src/main/java/com/logicalhost/app/KeepAliveService.java  background service + the floating bubble
- app/src/main/java/com/logicalhost/app/WebHost.java        one shared WebView (bot keeps running), openConsole()
- app/src/main/java/com/logicalhost/app/MainActivity.java   the screen
- app/src/main/java/com/logicalhost/app/NotifyBridge.java   notifications + botState() from the page
- app/src/main/assets/bridge.js                             watches the page's .float-bubble, sends signal alerts

Change the page the app opens: HOME_URL in WebHost.java.
Bubble icon: replace res/drawable/ic_fg.xml (or point addBubble() at a PNG of your mascot).

Website download link (always newest):
https://github.com/YOUR-NAME/YOUR-REPO/releases/latest/download/LogicalHost.apk
