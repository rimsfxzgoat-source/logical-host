package com.logicalhost.app;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;

import androidx.core.app.NotificationCompat;

/**
 * Keeps the app alive in the background and owns the ONE floating bubble.
 *
 * The bubble is a copy of the web app's own bubble (same look, same dot colours).
 * It is shown only when ALL of these are true:
 *   - the web page says the bot is running (botOn, sent by bridge.js)
 *   - the app screen is NOT in front (the web page draws its own bubble there)
 *   - the "display over other apps" permission is granted
 * Tapping it opens the app straight onto the web bot console.
 */
public class KeepAliveService extends Service {

    static final String ACTION_STOP = "com.logicalhost.app.STOP";
    private static final String CHANNEL = "running";
    private static final int NOTIF_ID = 1;

    static KeepAliveService instance;

    // State pushed by the web page (bridge.js -> NotifyBridge.botState). Main thread only.
    static boolean botOn = false;
    static boolean executing = false;
    static boolean eaOff = false;

    // Remembered bubble position (px) so it comes back where you left it.
    private static int savedX = Integer.MIN_VALUE;
    private static int savedY = Integer.MIN_VALUE;

    private PowerManager.WakeLock lock;
    private WindowManager wm;
    private FrameLayout bubble;
    private GradientDrawable ring;
    private GradientDrawable dotShape;
    private WindowManager.LayoutParams lp;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        botOn = false;       // never trust old state after a (re)start
        executing = false;
        eaOff = false;

        NotificationChannel ch = new NotificationChannel(
                CHANNEL, "Bot running", NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        lock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "logicalhost:bot");
        lock.setReferenceCounted(false);
        lock.acquire();

        WebHost.get(this);
        if (!MainActivity.visible) WebHost.park(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            botOn = false;
            removeBubble();
            Activity a = WebHost.activity;
            if (a != null) a.finish();
            WebHost.destroy();
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            return START_NOT_STICKY;
        }

        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIF_ID, n);
        }
        return START_STICKY;
    }

    private Notification buildNotification() {
        PendingIntent open = PendingIntent.getActivity(
                this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, KeepAliveService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(
                this, 1, stop, PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle("Logical Host is online")
                .setContentText("Bot is running. Tap to open.")
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(open)
                .addAction(0, "Stop", stopPi)
                .build();
    }

    // ---------------- the floating bubble ----------------

    /** Call from the main thread whenever botOn / app-visible / permission may have changed. */
    static void sync() {
        KeepAliveService s = instance;
        if (s != null) s.syncBubble();
    }

    private void syncBubble() {
        boolean want = botOn && !MainActivity.visible && Settings.canDrawOverlays(this);
        if (!want) {
            removeBubble();
        } else if (bubble == null) {
            addBubble();
        } else {
            paintBubble();
        }
    }

    private static int dp(float d, float v) {
        return (int) (v * d + 0.5f);
    }

    private void addBubble() {
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        final DisplayMetrics dm = getResources().getDisplayMetrics();
        final float d = dm.density;
        final int size = dp(d, 60);          // same 60px circle as the web bubble
        final int margin = dp(d, 8);

        // circle: radial gradient + 2dp ring, like .float-bubble
        ring = new GradientDrawable();
        ring.setShape(GradientDrawable.OVAL);
        ring.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        ring.setGradientRadius(size * 0.7f);
        ring.setGradientCenter(0.35f, 0.30f);
        ring.setColors(new int[]{0xFF2A3D99, 0xFF060914});

        FrameLayout root = new FrameLayout(this);
        root.setBackground(ring);
        root.setElevation(dp(d, 8));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_fg);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        int pad = dp(d, 9);
        logo.setPadding(pad, pad, pad, pad);
        root.addView(logo, new FrameLayout.LayoutParams(size, size));

        // status dot, top right (green running / orange executing / grey EA off)
        View dot = new View(this);
        dotShape = new GradientDrawable();
        dotShape.setShape(GradientDrawable.OVAL);
        dot.setBackground(dotShape);
        FrameLayout.LayoutParams dotLp = new FrameLayout.LayoutParams(dp(d, 14), dp(d, 14));
        dotLp.gravity = Gravity.TOP | Gravity.END;
        dotLp.topMargin = dp(d, 2);
        dotLp.rightMargin = dp(d, 2);
        root.addView(dot, dotLp);

        bubble = root;

        lp = new WindowManager.LayoutParams(
                size, size,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;

        if (savedX == Integer.MIN_VALUE) {
            savedX = dm.widthPixels - size - margin;
            savedY = (int) (dm.heightPixels * 0.55f);
        }
        lp.x = clampX(savedX, size, dm.widthPixels);
        lp.y = clampY(savedY, size, dm.heightPixels);

        root.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY;
            float touchX, touchY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                DisplayMetrics m = getResources().getDisplayMetrics();
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = lp.x;
                        startY = lp.y;
                        touchX = e.getRawX();
                        touchY = e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float dx = e.getRawX() - touchX;
                        float dy = e.getRawY() - touchY;
                        if (Math.abs(dx) > dp(m.density, 8) || Math.abs(dy) > dp(m.density, 8)) {
                            moved = true;
                        }
                        if (moved) {
                            lp.x = clampX(startX + (int) dx, size, m.widthPixels);
                            lp.y = clampY(startY + (int) dy, size, m.heightPixels);
                            update();
                        }
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        if (moved) {
                            // snap to the nearest side edge and remember the spot
                            boolean left = lp.x + size / 2 < m.widthPixels / 2;
                            lp.x = left ? margin : m.widthPixels - size - margin;
                            lp.y = clampY(lp.y, size, m.heightPixels);
                            savedX = lp.x;
                            savedY = lp.y;
                            update();
                        } else if (e.getAction() == MotionEvent.ACTION_UP) {
                            openConsoleInApp();
                        }
                        return true;
                    default:
                        return false;
                }
            }
        });

        try {
            wm.addView(bubble, lp);
            paintBubble();
        } catch (Exception ex) {
            bubble = null;
        }
    }

    private static int clampX(int x, int size, int screenW) {
        return Math.max(0, Math.min(x, screenW - size));
    }

    private static int clampY(int y, int size, int screenH) {
        return Math.max(0, Math.min(y, screenH - size));
    }

    private void update() {
        if (bubble == null) return;
        try {
            wm.updateViewLayout(bubble, lp);
        } catch (Exception ignored) {
        }
    }

    /** Colours follow the web bubble: blue ring + green dot; orange while executing; grey when EA is off. */
    private void paintBubble() {
        if (bubble == null || ring == null) return;
        float d = getResources().getDisplayMetrics().density;
        int ringColor = 0xFF3D6BFF;
        int dotColor = 0xFF33D17A;
        if (executing) {
            ringColor = 0xFFFF8A3D;
            dotColor = 0xFFFF8A3D;
        } else if (eaOff) {
            ringColor = 0xFF5B7396;
            dotColor = 0xFF5B7396;
        }
        ring.setStroke(dp(d, 2), ringColor);
        dotShape.setColor(dotColor);
        dotShape.setStroke(dp(d, 2), 0xFF05070C);
        bubble.invalidate();
    }

    private void removeBubble() {
        if (bubble != null) {
            try {
                wm.removeView(bubble);
            } catch (Exception ignored) {
            }
        }
        bubble = null;
        ring = null;
        dotShape = null;
    }

    /** Tap: bring the app to the front with the web bot console open. */
    private void openConsoleInApp() {
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_SINGLE_TOP
                | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        i.putExtra(MainActivity.EXTRA_OPEN_CONSOLE, true);
        try {
            startActivity(i);
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onDestroy() {
        botOn = false;
        removeBubble();
        if (lock != null && lock.isHeld()) lock.release();
        if (!MainActivity.visible) WebHost.destroy();
        instance = null;
        super.onDestroy();
    }
}
